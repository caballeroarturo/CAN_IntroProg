public class Main {

    public static void main(String[] args) {

        // Se crea el objeto calculadora
        Operaciones calculadora = new Operaciones();

        // Se crea el objeto calc2
        Operaciones calc2 = new Operaciones();

        // imprimir el estado inicial de la calculadora
        System.out.println(calculadora.obtenerResultado());

        calculadora.sumar(5, 5);

        // recuerda que el objeto tiene un estado, que es el resultado de la
        // ultima operacion y usarlo para la siguiente
        calculadora.sumar(20);
        System.out.println("Resultado: " + calculadora.obtenerResultado());

        calculadora.multiplicar(2);
        System.out.println("Resultado: " + calculadora.obtenerResultado());

        System.out.println("----------------------");
        calc2.sumar(25);
        calc2.dividir(5);
        System.out.println("Resultado: " + calc2.obtenerResultado());

        // para reiniciar la calculadora al estado inicial, que es 0
        calc2.reiniciar();
        System.out.println("Resultado: " + calc2.obtenerResultado());



    }
}




