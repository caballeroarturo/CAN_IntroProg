public class Main {

    public static void main(String[] args) {

        // constructores sobrecargados = Permite a una clase tener muchos constructores
        //                               con diferente lista de parámetros
        //                               Los objetos se pueden iniciar de diferentes formas.

        // Permite que quienes usen la clase puedan crear objetos de varias formas distintas,
        // sin tener que pasar siempre todos los datos.

        User user1 = new User("Fulgor");
        User user2 = new User("Sedano", "sedano@aol.com");
        User user3 = new User("Mata", "filomenomata@gmail.com", 27);
        User user4 = new User();

        System.out.println(user1.username);
        System.out.println(user1.email);
        System.out.println(user1.age);

        System.out.println(user2.username);
        System.out.println(user2.email);
        System.out.println(user2.age);

        System.out.println(user3.username);
        System.out.println(user3.email);
        System.out.println(user3.age);

        System.out.println(user4.username);
        System.out.println(user4.email);
        System.out.println(user4.age);
    }
}